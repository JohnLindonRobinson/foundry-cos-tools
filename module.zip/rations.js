// Ration Tracker: short rest = 1 unit, long rest = 4 units, 6 units per ration.
const UNITS_PER_RATION = 6;
const COST = { short: 1, long: 4 };

Hooks.on("dnd5e.restCompleted", async (actor, result) => {
  if (actor.type !== "character" || !actor.isOwner) return;
  const cost = result?.longRest ? COST.long : COST.short;
  const item = actor.items.find(i => /^rations/i.test(i.name));

  const qty = item?.system.quantity ?? 0;
  const spent = Math.min(item?.system.uses?.spent ?? 0, UNITS_PER_RATION);
  const total = qty > 0 ? (qty - 1) * UNITS_PER_RATION + (UNITS_PER_RATION - spent) : 0;

  let msg;
  if (total < cost) {
    if (item) await item.update({ "system.quantity": 0, "system.uses.max": String(UNITS_PER_RATION), "system.uses.spent": 0 });
    msg = `<b>${actor.name}</b> needed ${cost} ration unit(s) but had ${total}. <span style="color:red"><b>Went hungry!</b></span>`;
  } else {
    const left = total - cost;
    const newQty = Math.ceil(left / UNITS_PER_RATION);
    const newSpent = newQty > 0 ? newQty * UNITS_PER_RATION - left : 0;
    await item.update({
      "system.quantity": newQty,
      "system.uses.max": String(UNITS_PER_RATION),
      "system.uses.spent": newSpent
    });
    msg = `<b>${actor.name}</b> ate ${cost} ration unit(s). ${left} left (${newQty} ration${newQty === 1 ? "" : "s"}, ${UNITS_PER_RATION - newSpent || 0}/${UNITS_PER_RATION} in the open one).`;
  }
  ChatMessage.create({ content: msg, speaker: ChatMessage.getSpeaker({ actor }) });
});
