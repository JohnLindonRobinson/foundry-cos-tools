// Necroficer: prompt to repair Horrors with Soul Embers after a rest.
const MOD_R = "johnny-cos-tools";
const isNecro = a => a?.items?.some(i => i.type === "class" && i.system.identifier === "necroficer");

function hurtHorrors(nec) {
  const folder = game.folders.find(f => f.type === "Actor" && f.name === "Horrors");
  return game.actors.filter(a => a.folder?.id === folder?.id && a.testUserPermission(game.user, "OWNER")
    && a.system.attributes.hp.value < a.system.attributes.hp.max);
}

async function repairDialog(nec, title = "Repair Horror") {
  const embersItem = nec.items.find(i => i.name === "Soul Embers");
  const embers = embersItem?.system.uses?.value ?? 0;
  const hurt = hurtHorrors(nec);
  if (!embers || !hurt.length) return false;

  const res = await foundry.applications.api.DialogV2.prompt({
    window: { title: `${title} (${embers} Soul Embers)` },
    content: `<div class="form-group"><label>Horror</label><select name="h">${hurt.map(h =>
        `<option value="${h.id}">${h.name} (${h.system.attributes.hp.value}/${h.system.attributes.hp.max})</option>`).join("")}</select></div>
      <div class="form-group"><label>Embers to spend</label><input name="n" type="number" min="1" max="${embers}" value="1"></div>`,
    ok: { label: "Repair", callback: (ev, btn) => ({ h: btn.form.elements.h.value, n: Number(btn.form.elements.n.value) }) },
    rejectClose: false
  });
  if (!res || res.n < 1) return false;

  const n = Math.min(res.n, embers), h = game.actors.get(res.h), int = nec.system.abilities.int.mod;
  const roll = await new Roll(`${n}d6 + ${n * int}`).evaluate();
  const hp = h.system.attributes.hp;
  const healed = Math.min(roll.total, hp.max - hp.value);
  await h.update({ "system.attributes.hp.value": hp.value + healed });
  await embersItem.update({ "system.uses.spent": embersItem.system.uses.spent + n });
  await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: nec }),
    flavor: `${nec.name} stitches ${h.name} back together (${n} ember${n > 1 ? "s" : ""}): +${healed} HP` });
  return true;
}

// Keep offering until they cancel, run out of embers, or everything is healed.
async function restRepairs(nec) {
  while (await repairDialog(nec, "Rest: Repair Horrors")) {}
}

Hooks.on("dnd5e.restCompleted", (actor) => {
  if (!isNecro(actor)) return;
  const owner = game.users.find(u => !u.isGM && u.active && actor.testUserPermission(u, "OWNER"));
  if (owner === game.user || (!owner && game.user.isGM)) return restRepairs(actor);
  if (owner) game.socket.emit(`module.${MOD_R}`, { type: "repair", userId: owner.id, actorUuid: actor.uuid });
});

Hooks.once("ready", () => {
  game.modules.get(MOD_R).api ??= {};
  Object.assign(game.modules.get(MOD_R).api, {
    repair: nec => repairDialog(nec ?? game.user.character)
  });
  game.socket.on(`module.${MOD_R}`, async msg => {
    if (msg?.type !== "repair" || msg.userId !== game.user.id) return;
    restRepairs(await fromUuid(msg.actorUuid));
  });
});
