// When a Map Note with flags.world.anchor is opened, jump to that heading.
Hooks.on("activateNote", (note, options) => {
  const anchor = note.document.getFlag("world", "anchor");
  if (anchor) options.anchor = anchor;
});
