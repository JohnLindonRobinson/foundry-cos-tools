// GM-approved Soul Ember harvesting for the Necroficer.
const MOD = "johnny-cos-tools";

async function handleHarvest({ necUuid, tokenUuid, userId }) {
  if (game.user !== game.users.activeGM) return;
  const nec = await fromUuid(necUuid), tok = await fromUuid(tokenUuid);
  const embersItem = nec?.items.find(i => i.name === "Soul Embers");
  if (!embersItem || !tok?.actor) return;
  const whisper = [userId, game.user.id];
  const done = nec.getFlag("world", "harvested") ?? [];
  if (done.includes(tokenUuid)) return ChatMessage.create({ whisper, content: `<i>${tok.name} has already been harvested.</i>` });

  const cr = tok.actor.system.details?.cr ?? 0;
  const roundUp = game.settings.get(MOD, "harvestRoundUp");
  const gain = cr <= 0 ? 0 : roundUp ? Math.max(1, Math.floor(cr)) : Math.floor(cr);
  const user = game.users.get(userId);

  const ok = await foundry.applications.api.DialogV2.confirm({
    window: { title: "Harvest Soul Embers?" },
    content: `<p><b>${user?.name ?? "A player"}</b> wants <b>${nec.name}</b> to harvest <b>${tok.name}</b> (CR ${cr}) for <b>${gain}</b> Soul Ember${gain === 1 ? "" : "s"}.</p><p>Dead less than an hour? Ritual uninterrupted?</p>`,
    yes: { label: "Approve" }, no: { label: "Deny" }
  });
  if (!ok) return ChatMessage.create({ whisper, content: `<i>The soul of ${tok.name} has already slipped away. Nothing to harvest.</i>` });

  const spent = embersItem.system.uses.spent;
  const got = Math.min(gain, spent);
  await embersItem.update({ "system.uses.spent": spent - got });
  await nec.setFlag("world", "harvested", [...done, tokenUuid]);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: nec }),
    content: `<b>${nec.name}</b> performs the 10-minute ritual over <b>${tok.name}</b>, drawing out ${got} Soul Ember${got === 1 ? "" : "s"}.${gain > got ? ` <i>${gain - got} lost (heart is full).</i>` : ""}` });
}

Hooks.once("init", () => {
  game.settings.register(MOD, "harvestRoundUp", {
    name: "Harvest: fractional-CR corpses give 1 ember",
    hint: "If off, corpses below CR 1 (wolves, zombies, skeletons) give no Soul Embers.",
    scope: "world", config: true, type: Boolean, default: false
  });
});

Hooks.once("ready", () => {
  game.modules.get(MOD).api ??= {};
  Object.assign(game.modules.get(MOD).api, {
    requestHarvest: data => game.user.isGM ? handleHarvest(data) : game.socket.emit(`module.${MOD}`, { type: "harvest", data })
  });
  game.socket.on(`module.${MOD}`, msg => { if (msg?.type === "harvest") handleHarvest(msg.data); });
});
