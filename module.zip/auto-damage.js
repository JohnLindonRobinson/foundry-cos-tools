// Auto-roll damage when a GM-controlled NPC's attack hits a targeted token.
const seen = new WeakSet();
async function onAttack(rolls, data) {
  if (!Array.isArray(rolls) || !game.user.isGM) return;
  const roll = rolls[0];
  if (!roll || seen.has(roll)) return;
  seen.add(roll);
  const activity = data?.subject;
  if (!activity?.rollDamage || activity.actor?.type !== "npc") return;
  const targets = [...game.user.targets];
  if (!targets.length || roll.isFumble) return;
  const hit = roll.isCritical || targets.some(t => roll.total >= (t.actor?.system.attributes?.ac?.value ?? Infinity));
  if (!hit) return;
  await activity.rollDamage({ isCritical: !!roll.isCritical }, { configure: false });
}
Hooks.on("dnd5e.rollAttackV2", onAttack);
Hooks.on("dnd5e.rollAttack", onAttack);
